/*
 * Created on 25.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.anttask;

import java.io.File;

import net.sf.fjep.fatjar.builder.IConflictResolver;
import net.sf.fjep.fatjar.builder.ManifestConflictResolver;
import net.sf.fjep.utils.FileUtils;


/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FJManifestType {

    private boolean mergemanifests = true;
    public boolean isMergemanifests()                     { return mergemanifests; }
    public void setMergemanifests(boolean mergemanifests) { this.mergemanifests = mergemanifests; }
    
    private boolean removesigners = true;
    public boolean isRemovesigners()                      { return removesigners; }
    public void setRemovesigners(boolean removesigners)   { this.removesigners = removesigners; }
    
    private String mainclass = "";
    public String getMainclass()               { return mainclass; }
    public void setMainclass(String mainClass) { this.mainclass = mainClass; }

    private String classpath = "";
    public String getClasspath()               { return classpath; }
    public void setClassPath(String classpath) { this.classpath = classpath; }

    private String manifestfile = "";
    public String getManifestfile()                  { return manifestfile; }
    public void setManifestfile(String manifestfile) { this.manifestfile = manifestfile; }

    public String toString() {
        StringBuffer result = new StringBuffer();
        result.append("manifest[");
        if (mergemanifests)
            result.append("merge,");
        if (removesigners)
            result.append("removesigners,");
        if (!manifestfile.equals("")) {
            result.append("file='");
            result.append(manifestfile);
            result.append("',");
        }
        else {
            if (!mainclass.equals("")) {
                result.append("main='");
                result.append(mainclass);
                result.append("',");
            }
            if (!classpath.equals("")) {
                result.append("classpath='");
                result.append(classpath);
                result.append("',");
            }
        }
        result.setCharAt(result.length()-1, ']');
        return result.toString();
    }

    public IConflictResolver getConflictResolver() {
        ManifestConflictResolver resolver = new ManifestConflictResolver(mergemanifests);
        return resolver;
    }

    public String getManifestText() {
        String result = "";
        if (!manifestfile.equals("")) {
            result = FileUtils.readContent(new File(manifestfile));
        }
        else {
            result = "Manifest-Version: 1.0\r\n";
            result += "Created-By: Fat Jar Eclipse Plug-In\r\n";
            if ((mainclass != null) && !mainclass.trim().equals("")) 
                result += "Main-Class: " + mainclass + "\r\n";
            if ((classpath != null) && !classpath.trim().equals("")) 
                result += "Class-Path: " + classpath + "\r\n";
            result += "\r\n";
        }
        return result;
    }
}
