/*
 * Created on 25.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.anttask;

import java.util.ArrayList;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FJFileSourceType {

    private ArrayList excludes;
    private ArrayList excludesRX;

    public FJFileSourceType() {
        excludes = new ArrayList();
        excludesRX = new ArrayList();
    }

    private String path;
    public String getPath() {return path;}
    public void setPath(String path) {this.path = path;}

    private String relPath = "";
    public String getRelPath() {return relPath;}
    public void setRelPath(String relPath) {this.relPath = relPath;}

    private String virtualName = "";
    public String getVirtualName() {return virtualName;}
    public void setVirtualName(String virtualName) {this.virtualName = virtualName;}

    public void addConfigured(FJExcludeType exclude) {
        if (!exclude.getRelPath().equals("")) {
            excludes.add(exclude.getRelPath());
        }
        if (!exclude.getRegexp().equals("")) {
            excludesRX.add(exclude.getRegexp());
        }
    }
    public String[] getExcludes() {
        String[] result = (String[]) excludes.toArray(new String[excludes.size()]);
        return result;
    }

    public String[] getExcludesRX() {
        String[] result = (String[]) excludesRX.toArray(new String[excludesRX.size()]);
        return result;
    }

    
}
