/*
 * Created on 25.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.anttask;


/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FJExcludeType {

    private String relPath = "";
    public String getRelPath() {return relPath;}
    public void setRelPath(String relPath) {this.relPath = relPath;}

    private String regexp = "";
    public String getRegexp() {return regexp;}
    public void setRegexp(String regexp) {this.regexp = regexp;}
    
}
