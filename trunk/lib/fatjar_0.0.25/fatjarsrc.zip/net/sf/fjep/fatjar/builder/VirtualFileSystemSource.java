/*
 * Created on 31.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.builder;

import java.util.ArrayList;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class VirtualFileSystemSource extends AbstractFileSystemSource {

    private ArrayList elements;
    
    private int nextElementIndex = 0; 
    
    public VirtualFileSystemSource() {
        elements = new ArrayList();
    }
    
    public void add(IFileSystemElement element) {
        elements.add(element);
    }
    
    /* (non-Javadoc)
     * @see net.sf.fjep.fatjar.builder.AbstractFileSystemSource#nextUnqueuedElement()
     */
    protected IFileSystemElement nextUnqueuedElement() {
        IFileSystemElement result = null;
        if (nextElementIndex < elements.size()) {
            result = (IFileSystemElement) elements.get(nextElementIndex);
            nextElementIndex += 1;
        }
        return result;
    }

}
