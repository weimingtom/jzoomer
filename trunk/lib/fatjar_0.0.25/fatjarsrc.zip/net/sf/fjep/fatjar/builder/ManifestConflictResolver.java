/*
 * Created on 30.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.builder;

import java.io.File;

import net.sf.fjep.utils.FileUtils;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ManifestConflictResolver implements IConflictResolver {

    private boolean mergeManifests;
    
    
    public ManifestConflictResolver(boolean mergeManifests) {
        this.mergeManifests = mergeManifests;
    }
    
    /**
     * merge old manifest-body into new manifest
     */
    public boolean handleConflict(File conflictOutputFile, IFileSystemElement fileSystemElement) {
        
        boolean resolved = false;
        if (conflictOutputFile.getName().equalsIgnoreCase("MANIFEST.MF")) {
//            System.out.println("merging '" + conflictOutputFile + "' new element='" + fileSystemElement + "'");
            String oldManifest = FileUtils.readContent(conflictOutputFile);
//            System.out.println("oldManifest=[" + oldManifest + "]");
            String newManifest = FileUtils.readContent(fileSystemElement.getStream());
//            System.out.println("newManifest=[" + newManifest + "]");
            String mergeManifest = mergeManifests(oldManifest, newManifest);
//            System.out.println("mergeManifest=[" + mergeManifest + "]");
            FileUtils.writeToFile(conflictOutputFile, mergeManifest);
            resolved = true;
        }
        return resolved;
    }

    /**
     * @param oldManifest
     * @param newManifest
     * @return
     */
    private String mergeManifests(String oldManifest, String newManifest) {
        String result;
        if (!mergeManifests) {
            result = oldManifest;
        }
        else {
            String newIndividualSection = getIndividualSection(newManifest);
            result = oldManifest;
            if (!oldManifest.endsWith("\r\n")) {
                result += "\r\n\r\n";
            } else if (!oldManifest.endsWith("\r\n\r\n")) {
                result += "\r\n";
            }
            result += newIndividualSection;
        }
        return result;
    }

    /**
     * @param manifestText
     * @return
     */
    private String getIndividualSection(String manifestText) {
        String result = "";
        int lastpos = 0;
        int pos = manifestText.indexOf('\n', lastpos);
        while (pos >0) {
            String line = manifestText.substring(lastpos, pos);
            if (line.trim().equals("")) {
                result = manifestText.substring(pos+1);
                break;
            }
            lastpos = pos+1;
            pos = manifestText.indexOf('\n', lastpos);
        }
        return result;
    }

}
