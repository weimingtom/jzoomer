/*
 * Created on 19.11.2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.builder;

import java.io.File;
import java.io.InputStream;
import java.util.jar.JarEntry;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface IJarBuilder {
        /**
         * synchronized for using syncBuffer
         * @param f file to add
         * @param relName relative name inside jar 
         */
        public abstract void add(File f, String relName);

        /**
         * synchronized for using syncBuffer
         */
        public abstract void add(IFileSystemElement src);

        /**
         * synchronized for using syncBuffer
         */
        public abstract void add(JarEntry srcEntry, InputStream in);

        public abstract void close();
}