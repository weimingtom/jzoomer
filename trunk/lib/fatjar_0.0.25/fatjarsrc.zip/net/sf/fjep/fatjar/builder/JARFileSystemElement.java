/*
 * Created on 05.09.2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.builder;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class JARFileSystemElement extends AbstractFileSystemElement {

	private JarFile jarFile;
	private JarEntry jarEntry;

	/**
	 * 
	 */
	public JARFileSystemElement(JarFile jarFile, JarEntry jarEntry, String relFolder) {
		this.jarFile = jarFile;
		this.jarEntry = jarEntry;
		String entryName = jarEntry.getName();
		entryName = entryName.replace('/', File.separatorChar);
		folder = relFolder;
		String dir; 
		if (jarEntry.isDirectory()) {
			// cut last separatorChar
			dir = entryName.substring(0, entryName.length()-1);
			name = null;
		}
		else {
			int pos = entryName.lastIndexOf(File.separatorChar);
			if (pos == -1) {
				dir = "";
				name = entryName;
			} else {
				dir = entryName.substring(0, pos);
				name = entryName.substring(pos + 1);
			}
		}
		if (relFolder.equals(""))
			folder = dir;
		else if (dir.equals(""))
			folder = relFolder;
		else
			folder = relFolder + File.separatorChar + dir;
	}

	/* (non-Javadoc)
	 * @see net.sf.fjep.fatjar.builder.IFileSystemElement#isFolder()
	 */
	public boolean isFolder() {
		return jarEntry.isDirectory();
	}

	/* (non-Javadoc)
	 * @see net.sf.fjep.fatjar.builder.IFileSystemElement#getSize()
	 */
	public long getSize() {
		return jarEntry.getSize();
	}

	/* (non-Javadoc)
	 * @see net.sf.fjep.fatjar.builder.IFileSystemElement#getStream()
	 */
	public InputStream getStream() {
		InputStream result = null;
		try {
			result = jarFile.getInputStream(jarEntry);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}


	/* (non-Javadoc)
	 * @see net.sf.fjep.fatjar.builder.IFileSystemElement#lastModificationTime()
	 */
	public long lastModificationTime() {
		return jarEntry.getTime();
	}

}
