/*
 * Created on 30.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.builder;

import java.io.File;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface IConflictResolver {

    /**
     * @param conflictOutputFile
     * @param fileSystemElement
     * @return true if conflict was resolved (no other resolver will 
     * then be asked to handle this conflict),
     * return false if conflict was not resolved (the next resolver will
     * be called to handle this conflict.
     * 
     */
    boolean handleConflict(File conflictOutputFile, IFileSystemElement fileSystemElement);

    
    
}
