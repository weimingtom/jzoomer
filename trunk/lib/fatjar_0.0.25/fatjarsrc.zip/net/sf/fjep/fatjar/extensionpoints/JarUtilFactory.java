/*
 * Created on 20.11.2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.extensionpoints;

import java.io.File;
import java.io.IOException;

import net.sf.fjep.fatjar.builder.FileSystemSourceFilter;
import net.sf.fjep.fatjar.builder.IFileSystemSource;
import net.sf.fjep.fatjar.builder.IJarBuilder;
import net.sf.fjep.fatjar.builder.JARFileSystemSource;
import net.sf.fjep.fatjar.builder.JarBuilder;
import net.sf.fjep.fatjar.builder.NativeFileSystemSource;

/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class JarUtilFactory implements IJarUtilFactory {

        public IJarBuilder createJarBuilder(String jarFileName) {
                return new JarBuilder(jarFileName);
        }

        public IFileSystemSource createJARFileSystemSource(String jarFilename, String relFolder) {

                IFileSystemSource result = null;
                try {
                        result = new JARFileSystemSource(jarFilename, relFolder);
                } catch (IOException e) {
                        e.printStackTrace();
                }
                return result;
        }
        
        public IFileSystemSource createNativeFileSystemSource(File folder, String relFolder) {

                IFileSystemSource result = new NativeFileSystemSource(folder, relFolder);
                return result;
        }

        /* (non-Javadoc)
         * @see net.sf.fjep.fatjar.extensionpoints.IJarUtilFactory#createFileSystemSourceFilter(net.sf.fjep.fatjar.builder.IFileSystemSource, java.lang.String[])
         */
        public IFileSystemSource createFileSystemSourceFilter(IFileSystemSource source, String[] excludes, String[] regexpExcludes) {

                IFileSystemSource result = new FileSystemSourceFilter(source, excludes, regexpExcludes);
                return result;
        }
        
}
