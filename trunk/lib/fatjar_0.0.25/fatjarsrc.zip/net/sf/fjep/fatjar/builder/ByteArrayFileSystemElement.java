/*
 * Created on 31.01.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package net.sf.fjep.fatjar.builder;

import java.io.ByteArrayInputStream;
import java.io.InputStream;


/**
 * @author feri
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ByteArrayFileSystemElement extends AbstractFileSystemElement {

    byte[] content;
    
    public ByteArrayFileSystemElement(String folder, String name, byte[] content) {
        this.folder = folder;
        this.name = name;
        this.content = content;
    }

    /* (non-Javadoc)
     * @see net.sf.fjep.fatjar.builder.IFileSystemElement#getSize()
     */
    public long getSize() {
        return content.length;
    }
    /* (non-Javadoc)
     * @see net.sf.fjep.fatjar.builder.IFileSystemElement#getStream()
     */
    public InputStream getStream() {
        InputStream in = new ByteArrayInputStream(content);
        return in;
    }
    
}
